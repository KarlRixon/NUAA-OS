gcc -o good_for_writer good_for_writer.c -lpthread
./good_for_writer < input.txt

